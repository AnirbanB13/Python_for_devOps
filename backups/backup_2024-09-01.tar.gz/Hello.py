Name = input("Enter your name: ")
print("Hello", Name )