import os #import a library into your code

print(os.system('chkdsk C:'))
