num1 = int(input("Enter First Number: "))
num2 = int(input("Enter Second Number: " ))

print(type(num1))
print(type(num2))
sum_of_num = num1 + num2

print("Sum of two numbers is: ", sum_of_num)

diff_of_num = num1 - num2

print("diff of two Numbers:", diff_of_num)

product_of_num = num1 * num2

print("product of two Numbers:", product_of_num)

division_of_num = num1 / num2

print("division of two Numbers:", division_of_num)



                 
        